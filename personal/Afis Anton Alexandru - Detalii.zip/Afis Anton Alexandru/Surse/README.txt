Platforme folosite:
https://bigjpg.com/ - Upscaling al drona.jfif la drona.jpg apoi la drona(1).jpg 
https://upscalepics.com/ - Upscaling care nu a dat un rezultat satisfacator al drona.jfif la mai multe imagini gasite in /Surse/Assets
https://www.vectorstock.com/royalty-free-vectors/minimalist-drone-vectors / https://www.google.com/search?q=minimalistic+drone+&tbm=isch&ved=2ahUKEwjOna2YlqD0AhXZhP0HHZXbBqAQ2-cCegQIABAA&oq=minimalistic+drone+&gs_lcp=CgNpbWcQAzoHCCMQ7wMQJzoKCCMQ7wMQ6gIQJzoICAAQgAQQsQM6CwgAEIAEELEDEIMBOgUIABCABDoECAAQQzoICAAQsQMQgwE6BAgAEB5Q6Q9YpShgpSloAXAAeACAAYUBiAHBEZIBBDAuMTmYAQCgAQGqAQtnd3Mtd2l6LWltZ7ABCsABAQ&sclient=img&ei=kl2VYc6MGdmJ9u8PlbebgAo&bih=1009&biw=1858#imgrc=E-qNdXT0ObfS3M
^- Sursa imagine originala (drone.jfif)